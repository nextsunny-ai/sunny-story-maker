import { type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

// LOCAL 전용 — 혼자 쓰는 PC라 인증 우회. redirect 없음.
// V2 (Vercel)의 middleware.ts는 다른 코드 (정공법 redirect).
export async function middleware(request: NextRequest) {
  const { response } = await updateSession(request);
  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
