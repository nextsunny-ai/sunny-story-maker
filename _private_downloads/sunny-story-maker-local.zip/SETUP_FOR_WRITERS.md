# SUNNY Story Maker — 작가용 로컬 셋업 (Mac)

> 본인 Mac에 Story Maker 설치 → **Claude Pro/Max 구독 안에서 무료** 사용.

## 사전 확인 (이미 다 갖춘 분이면 스킵)

- [x] **Claude Pro/Max 구독** + Claude Code 설치/로그인 완료
- [ ] **Node.js** 설치 (없으면 https://nodejs.org → LTS)

확인:
```bash
node --version    # v20+ 면 OK
claude --version  # Claude Code 작동 확인
```

## 셋업 (5분)

### 1. 코드 받기

```bash
cd ~
git clone https://github.com/nextsunny-ai/sunny-story-maker.git SUNNY_Story_Maker_LOCAL
cd SUNNY_Story_Maker_LOCAL
git checkout v2-wip
npm install
```

### 2. `.env.local` 만들기

```bash
cat > .env.local << 'EOF'
USE_CLAUDE_CODE=true
ANTHROPIC_API_KEY=
ANTHROPIC_MODEL=opus
ANTHROPIC_MODEL_FAST=haiku

NEXT_PUBLIC_SUPABASE_URL=https://lcasxovjrgbnraxzyvnf.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_4O8VnABcy6xEansgj0ccnA_c4u5Efz0

INVITE_CODE=SUNNY2026!
EOF
```

→ Supabase 키는 위에 적힌 그대로 사용 (사장님과 같은 DB 공유, 작가별 격리됨).

### 3. 바탕화면 바로가기 (`.command` 파일)

```bash
cat > ~/Desktop/Story_Maker.command << 'EOF'
#!/bin/bash
cd ~/SUNNY_Story_Maker_LOCAL
PORT=3001

# 이미 떠있으면 브라우저만 열기
if lsof -ti:$PORT > /dev/null 2>&1; then
    open "http://localhost:$PORT"
    exit 0
fi

# 새로 띄우기 + 브라우저
npm run dev &
sleep 6
open "http://localhost:$PORT"
EOF

chmod +x ~/Desktop/Story_Maker.command
```

### 4. 실행

바탕화면 **`Story_Maker.command`** 더블클릭 → 5~7초 후 브라우저 자동.

**Mac 첫 실행 시 보안 경고**:
- "확인되지 않은 개발자" 경고 뜨면
- 시스템 환경설정 → 보안 및 개인 정보 보호 → "확인 없이 열기" 허용

## 사용

- **시작**: 바탕화면 `Story_Maker.command` 더블클릭
- **종료**: 떠있는 Terminal 창에서 `Ctrl+C` 또는 창 닫기
- **URL**: `http://localhost:3001`

## 비용

- **Story Maker** = $0
- **Claude API** = $0 (Claude Code = 본인 Pro/Max 구독)
- **Supabase** = $0
- → **본인 Claude Pro/Max만 부담**

## 데이터

- 작품/버전/채팅/학습 = Supabase 자동 저장
- 본인 작품만 본인이 봄 (writer_id 격리)
- 한글/워드 다운로드 = 본인 Mac에 저장

## 업데이트

새 기능 나오면:
```bash
cd ~/SUNNY_Story_Maker_LOCAL
git pull
npm install
```

## 막힐 때 → 사장님께 카톡 + 화면 캡처

---

## 빠른 셋업 (한 줄 요약)

```bash
cd ~ && git clone https://github.com/nextsunny-ai/sunny-story-maker.git SUNNY_Story_Maker_LOCAL && cd SUNNY_Story_Maker_LOCAL && git checkout v2-wip && npm install
# 그 다음 .env.local 만들고 바탕화면 .command 만들면 끝
```