"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ICONS } from "@/lib/icons";
import { Markdown } from "@/components/Markdown";
import { LibraryPicker } from "@/components/LibraryPicker";

export interface WorkInfo {
  title: string;
  chapter: string;
  elapsed: string;
  medium: string;
}

export interface Para {
  id: string;
  n: number;
  label: string;
  text: string;
  status: "done" | "streaming" | "pending";
  streamTarget?: string;
  notes?: string;  // AI 자가 검증·분석·다음 단계 (본문에서 마커로 분리됨, "💭 분석" 클릭 시 표시)
}

interface WriteCanvasProps {
  work: WorkInfo;
  paras: Para[];
  paused: boolean;
  onPauseToggle: () => void;
  onRewrite: (id: string) => void;
  onEdit?: (id: string, newText: string) => void;       // 작가 직접 수정 저장 (단락별)
  onEditAll?: (fullText: string) => void;                // ★ 본문 전체를 한 번에 수정
  onContinue?: (id: string) => void;                     // 이 단락 다음에 이어쓰기
  onDownload?: (format: "docx" | "txt") => void;        // 본문 다운로드 (워드/텍스트)
  bookOpen: boolean;
  onBookToggle: () => void;
  notesCount: number;
  aiBusy?: boolean;                                      // ★ 외부 AI 호출 진행 중 여부 — 스탑 버튼 노출 통제
}

export function WriteCanvas({
  work, paras, paused, onPauseToggle, onRewrite, onEdit, onEditAll, onContinue, onDownload, bookOpen, onBookToggle, notesCount, aiBusy,
}: WriteCanvasProps) {
  const I = ICONS;
  const containerRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  // 작품 변경 모달 — 사장님 명시: 작업실에서 다른 작품 불러오기
  const [showProjectPicker, setShowProjectPicker] = useState(false);

  // 새 빈 작품 시작 (현재 작업실에서 = 새 작품으로 전환)
  const startNewBlank = () => {
    const blankIdea = `새 작품 ${new Date().toLocaleDateString("ko-KR")}`;
    const params = new URLSearchParams({
      mode: "new",
      idea: blankIdea,
      genre: "A",
      fast: "1",
      blank: "1",
    });
    router.push(`/write?${params.toString()}`);
    router.refresh();
  };

  // ★ 전체 수정 모드 — 본문 전체를 한 textarea에서 통째로 편집
  const [editingAll, setEditingAll] = useState(false);
  const [draftAll, setDraftAll] = useState("");

  const startEditAll = () => {
    const fullText = paras
      .filter(p => p.text && p.text.trim())
      .map(p => p.text)
      .join("\n\n");
    setDraftAll(fullText);
    setEditingAll(true);
  };
  const saveEditAll = () => {
    if (onEditAll) onEditAll(draftAll);
    setEditingAll(false);
  };
  const cancelEditAll = () => {
    setEditingAll(false);
  };

  // 새 글자가 써질 때 자동 스크롤 — wcanvas-body 컨테이너 내부 scroll 강제
  useEffect(() => {
    const streaming = paras.find(p => p.status === "streaming");
    if (!streaming) return;
    const container = containerRef.current;
    if (!container) return;
    // 컨테이너 자체를 맨 아래로 (sticky bottom)
    container.scrollTop = container.scrollHeight;
  }, [paras]);

  const totalChars = paras.reduce((acc, p) => acc + p.text.length, 0);
  const doneCount = paras.filter(p => p.status === "done").length;
  const isStreaming = paras.some(p => p.status === "streaming");

  return (
    <section className="wcanvas">
      {/* 헤더 */}
      <header className="wcanvas-head">
        <div className="wcanvas-head-left">
          <div className="wcanvas-head-title">
            <span className="wcanvas-head-mark">{I.book || I.write}</span>
            <h1>{work.title}</h1>
            <span className="wcanvas-head-chapter">{work.chapter}</span>
          </div>
          <div className="wcanvas-head-meta">
            <span>{work.medium}</span>
            <span className="wcanvas-head-dot">·</span>
            <span>{work.elapsed}</span>
            <span className="wcanvas-head-dot">·</span>
            <span>{totalChars.toLocaleString()}자</span>
            <span className="wcanvas-head-dot">·</span>
            <span>{doneCount}/{paras.length} 단락</span>
          </div>
        </div>
        <div className="wcanvas-head-right">
          <span className="wcanvas-saved">
            <span className="wcanvas-saved-dot"></span>
            자동 저장됨 · 방금
          </span>
          {(isStreaming || aiBusy) && (
            <button
              type="button"
              className={"wcanvas-pause" + (paused ? " is-paused" : "")}
              onClick={onPauseToggle}
              title="AI 즉시 중지"
              style={{
                background: "var(--coral)",
                color: "#fff",
                border: "1px solid var(--coral)",
                fontWeight: 700,
              }}
            >
              🛑 중지
            </button>
          )}
          {doneCount > 0 && !isStreaming && !editingAll && (
            <>
              <button
                type="button"
                className="wcanvas-book-toggle"
                onClick={async () => {
                  const fullText = paras
                    .filter(p => p.text && p.text.trim())
                    .map(p => p.text)
                    .join("\n\n");
                  if (!fullText) return;
                  try {
                    await navigator.clipboard.writeText(fullText);
                    const btn = document.activeElement as HTMLElement | null;
                    if (btn) {
                      const orig = btn.querySelector("span:last-child");
                      const before = orig?.textContent || "";
                      if (orig) orig.textContent = "✓ 복사됨";
                      setTimeout(() => { if (orig) orig.textContent = before; }, 1200);
                    }
                  } catch { /* ignore */ }
                }}
                title="본문 전체 복사"
              >
                <span className="wcanvas-book-toggle-icon">📋</span>
                <span>전체 카피</span>
              </button>
              {onEditAll && (
                <button
                  type="button"
                  className="wcanvas-book-toggle"
                  onClick={startEditAll}
                  title="본문 전체를 한 번에 수정"
                >
                  <span className="wcanvas-book-toggle-icon">✎</span>
                  <span>전체 수정</span>
                </button>
              )}
            </>
          )}
          {onDownload && doneCount > 0 && (
            <>
              <button
                type="button"
                className="wcanvas-book-toggle"
                onClick={() => onDownload("docx")}
                title="본문을 워드(.docx)로 다운로드"
              >
                <span className="wcanvas-book-toggle-icon">{I.download}</span>
                <span>워드</span>
              </button>
              <button
                type="button"
                className="wcanvas-book-toggle"
                onClick={() => onDownload("txt")}
                title="본문을 텍스트(.txt)로 다운로드"
              >
                <span className="wcanvas-book-toggle-icon">{I.download}</span>
                <span>TXT</span>
              </button>
            </>
          )}
          <button
            type="button"
            className="wcanvas-book-toggle"
            onClick={() => setShowProjectPicker(true)}
            title="다른 작품으로 변경"
            style={{ background: "transparent", border: "1px solid var(--line)" }}
          >
            <span className="wcanvas-book-toggle-icon">📁</span>
            <span>작품 변경</span>
          </button>
          <button
            type="button"
            className="wcanvas-book-toggle"
            onClick={startNewBlank}
            title="새 빈 작품 시작"
            style={{ background: "transparent", border: "1px solid var(--line)" }}
          >
            <span className="wcanvas-book-toggle-icon">+</span>
            <span>새 작품</span>
          </button>
          {!bookOpen && (
            <button
              type="button"
              className="wcanvas-book-toggle"
              onClick={onBookToggle}
              title="작가 노트 · AI 흐름 · 대화 열기"
            >
              <span className="wcanvas-book-toggle-icon">{I.book || I.write}</span>
              <span>작가노트</span>
              {notesCount ? <span className="wcanvas-book-toggle-badge">{notesCount}</span> : null}
            </button>
          )}
        </div>
      </header>

      {/* 본문 — 원고지 (스크롤 강제: CSS .wcanvas-body가 안 통할 환경 대비 inline 백업) */}
      <div
        className="wcanvas-body"
        ref={containerRef}
        style={{
          flex: 1,
          minHeight: 0,
          maxHeight: "calc(100vh - 80px)",
          overflowY: "auto",
          scrollBehavior: "smooth",
        }}
      >
        <div className="wcanvas-page">
          {editingAll ? (
            // ★ 전체 수정 모드 — 본문 통째로 textarea
            <div style={{ display: "flex", flexDirection: "column", gap: 12, padding: "20px 0" }}>
              <div style={{ fontSize: 12, color: "var(--ink-3)", lineHeight: 1.5 }}>
                본문 전체를 통째로 수정합니다. 단락 사이는 빈 줄(2번 엔터)로 구분 — 저장 시 자동으로 단락 분리됩니다.
              </div>
              <textarea
                value={draftAll}
                onChange={(e) => setDraftAll(e.target.value)}
                autoFocus
                style={{
                  width: "100%",
                  minHeight: "60vh",
                  padding: "16px 18px",
                  fontSize: 14,
                  lineHeight: 1.75,
                  fontFamily: "var(--font-display)",
                  color: "var(--ink-1)",
                  background: "var(--bg)",
                  border: "1px solid var(--coral)",
                  borderRadius: 12,
                  resize: "vertical",
                  whiteSpace: "pre-wrap",
                }}
              />
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  type="button"
                  onClick={saveEditAll}
                  style={{
                    padding: "10px 18px", fontSize: 13, fontWeight: 700,
                    background: "var(--coral)", color: "#fff",
                    border: "1px solid var(--coral)", borderRadius: 10,
                    cursor: "pointer",
                  }}
                >✓ 전체 저장</button>
                <button
                  type="button"
                  onClick={cancelEditAll}
                  style={{
                    padding: "10px 18px", fontSize: 13,
                    background: "transparent", color: "var(--ink-3)",
                    border: "1px solid var(--line)", borderRadius: 10,
                    cursor: "pointer",
                  }}
                >취소</button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(draftAll);
                      alert("✓ 전체 본문 복사됨");
                    } catch { /* ignore */ }
                  }}
                  style={{
                    padding: "10px 18px", fontSize: 13,
                    background: "transparent", color: "var(--coral-deep)",
                    border: "1px solid var(--coral)", borderRadius: 10,
                    cursor: "pointer",
                    marginLeft: "auto",
                  }}
                >📋 전체 카피</button>
              </div>
            </div>
          ) : (
            <>
              {paras.map((p, i) => (
                <Paragraph
                  key={p.id}
                  p={p}
                  i={i}
                  onRewrite={() => onRewrite(p.id)}
                  onEdit={onEdit ? (newText) => onEdit(p.id, newText) : undefined}
                  onContinue={onContinue ? () => onContinue(p.id) : undefined}
                  paused={paused}
                />
              ))}

              {paras.every(p => p.status !== "streaming") &&
               paras.every(p => p.status !== "pending") &&
               paras.length > 0 && (
                <div className="wcanvas-end">
                  <span>초고 완료 · 다음 단계로 넘어가시겠어요?</span>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* 작품 변경 모달 — 사장님 명시: 작업실에서 다른 작품 불러오기 */}
      <LibraryPicker
        open={showProjectPicker}
        onClose={() => setShowProjectPicker(false)}
        title="작업할 작품 선택"
        subtitle="다른 작품으로 즉시 전환합니다. 현재 작품은 자동 저장됨."
        onPick={(work) => {
          router.push(`/write?mode=continue&project=${encodeURIComponent(String(work.id))}`);
          // mode=continue 진입 시 = 그 작품 자동 복원
          setTimeout(() => router.refresh(), 50);
        }}
      />
    </section>
  );
}

function Paragraph({ p, paused, onRewrite, onEdit, onContinue }: {
  p: Para;
  i: number;
  onRewrite: () => void;
  onEdit?: (newText: string) => void;
  onContinue?: () => void;
  paused: boolean;
}) {
  const isStreaming = p.status === "streaming";
  const isDone = p.status === "done";
  const isPending = p.status === "pending";

  // 인라인 직접 편집 모드
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(p.text);

  const startEdit = () => {
    setDraft(p.text);
    setEditing(true);
  };
  const saveEdit = () => {
    if (onEdit) onEdit(draft);
    setEditing(false);
  };
  const cancelEdit = () => {
    setDraft(p.text);
    setEditing(false);
  };

  return (
    <div
      className={"wpara is-" + p.status + (paused && isStreaming ? " is-paused" : "")}
      data-para-id={p.id}
    >
      <div className="wpara-gutter">
        <span className="wpara-num">{String(p.n).padStart(2, "0")}</span>
        <span className="wpara-label">{p.label}</span>
      </div>

      <div className="wpara-body">
        {isPending ? (
          <div className="wpara-pending">
            <span className="wpara-pending-dot"></span>
            <span>대기 중</span>
          </div>
        ) : editing ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              autoFocus
              style={{
                width: "100%",
                minHeight: 200,
                padding: "12px 14px",
                fontSize: 14,
                lineHeight: 1.7,
                fontFamily: "var(--font-display)",
                color: "var(--ink-1)",
                background: "var(--bg)",
                border: "1px solid var(--coral)",
                borderRadius: 10,
                resize: "vertical",
                whiteSpace: "pre-wrap",
              }}
            />
            <div style={{ display: "flex", gap: 6 }}>
              <button type="button" className="wpara-action" onClick={saveEdit} title="수정 저장">
                <span className="wpara-action-icon">✓</span>
                <span>저장</span>
              </button>
              <button type="button" className="wpara-action" onClick={cancelEdit} title="취소">
                <span className="wpara-action-icon">✕</span>
                <span>취소</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="wpara-text">
            <Markdown text={p.text} />
            {isStreaming && (
              <span className={"wpara-cursor" + (paused ? " is-paused" : "")}></span>
            )}
          </div>
        )}

        {isDone && !editing && (
          <div className="wpara-actions">
            <button type="button" className="wpara-action" onClick={onRewrite} title="이 단락 다시 쓰기">
              <span className="wpara-action-icon">↻</span>
              <span>다시 써</span>
            </button>
            <button type="button" className="wpara-action" onClick={startEdit} title="직접 수정">
              <span className="wpara-action-icon">✎</span>
              <span>수정</span>
            </button>
            <button
              type="button"
              className="wpara-action"
              onClick={async (e) => {
                if (!p.text) return;
                try {
                  await navigator.clipboard.writeText(p.text);
                  const btn = e.currentTarget;
                  const span = btn.querySelector("span:last-child");
                  if (span) {
                    const before = span.textContent;
                    span.textContent = "✓ 복사됨";
                    setTimeout(() => { span.textContent = before; }, 1200);
                  }
                } catch { /* ignore */ }
              }}
              title="이 단락 텍스트 복사"
            >
              <span className="wpara-action-icon">📋</span>
              <span>복사</span>
            </button>
            <button
              type="button"
              className="wpara-action"
              onClick={onContinue}
              disabled={!onContinue}
              title="이어서 더 쓰기 (다음 단락 추가)"
            >
              <span className="wpara-action-icon">+</span>
              <span>더 쓰기</span>
            </button>
          </div>
        )}

        {isStreaming && !paused && (
          <div className="wpara-stream-ctrl">
            <span className="wpara-stream-status">
              <span className="wpara-stream-spinner"></span>
              써내려가는 중
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
