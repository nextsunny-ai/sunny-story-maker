# Sunny Story Maker — LOCAL v2.4

> 2026-05-04 빌드. 한국 시나리오 작가용 12매체 협업 도구.

## v2.4 변경 (2026-05-04)

- **★ 미니 채팅 (협업 모드)** — 카드 결과 = 같이 다듬기. "더 심플하게"·"주인공 이름 박을까?" 등 디렉션 → AI 응답 → 「✓ 카드에 박기」
- **캐릭터 = 3번째로 이동** — 제목·로그라인·**캐릭터**·주제·시놉시스·기승전결 (사장님 30년 CD 흐름)
- **6항목 자유 선택** — 강제 순차 X. 작가 = "시놉시스만"·"캐릭터만" 자유
- **시나리오 형식 강제** — 한국 영화·드라마 표준 정밀 (씬 헤딩·하위 씬·E·자막·CUT TO)
- **줄간격 1.5** — 옛 1.85 → 표준 1.5 (한국 시나리오 표준)
- **리뷰 통합 → 개별 순서** — 종합 한눈에 + 페르소나별 12 문항
- **사적 정보 보호 강화** — 외부 작가에게 = 자료 작성자 사적 정보 노출 X

## 셋업 (5~10분 — 처음 1번만)

### Mac
1. ZIP 압축 해제
2. 폴더 안 `setup.command` **더블클릭**
3. (필요시) "확인 안 된 개발자" → 시스템 환경설정 → 보안 → "허용"
4. 스크립트 = Node.js·npm·Claude Code CLI·의존성 자동 + 첫 실행
5. 다음부터는 = 바탕화면 바로가기

### Windows
1. ZIP 압축 해제
2. 폴더 안 `setup_windows.ps1` 우클릭 → "PowerShell로 실행"
3. (필요시) `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` 1회
4. 스크립트가 다 자동
5. 다음부터는 = `start_storymaker.vbs` 더블클릭

## Claude 로그인 (★ API 비용 0원)

```bash
claude /login
```
→ Claude Pro/Max 본인 계정 로그인 → 본인 토큰으로 작동.

## .env.local

```
USE_CLAUDE_CODE=true            # OAuth 모드
ANTHROPIC_API_KEY=              # 비워둠
NEXT_PUBLIC_SUPABASE_URL=...    # 사장님께 받음
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
INVITE_CODE=SUNNY2026!
```

## 회원가입·로그인

- 회원가입 = 초대 코드 `SUNNY2026!`
- 비번 찾기 = 로그인 페이지 → 「비밀번호 찾기」 → 이메일 → 링크 → 새 비번

## 사용

```bash
npm run dev      # http://localhost:3001
```

## 작품 저장

작품 = 이 폴더 안 `_works/` 폴더에 자동 저장.
- 폴더 옮기면 = 작품도 같이 이동
- 백업 = 이 폴더 통째로 복사

## 새 버전 받기

다운로드 페이지 (`/download`)에서 = 새 zip 받음. 작품 = 그대로 유지 (supabase + 로컬).
