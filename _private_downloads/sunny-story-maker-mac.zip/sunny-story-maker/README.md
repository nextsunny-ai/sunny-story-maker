# Sunny Story Maker — LOCAL v2.3

> 2026-05-04 빌드. 한국 작가용 12매체 시나리오 작업실.

## 셋업 (5~10분 — 처음 1번만)

### Mac
1. ZIP 압축 해제
2. 폴더 안 `setup.command` **더블클릭**
3. (필요시) "확인 안 된 개발자" → 시스템 환경설정 → 보안 → "허용"
4. 스크립트가 = Node.js·npm·Claude Code CLI·의존성 자동 설치 + 첫 실행
5. 다음부터는 = 바탕화면 바로가기 더블클릭

### Windows
1. ZIP 압축 해제
2. 폴더 안 `setup_windows.ps1` 우클릭 → "PowerShell로 실행"
3. (필요시) `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` 1회 실행
4. 스크립트가 다 자동
5. 다음부터는 = `start_storymaker.vbs` 더블클릭

## Claude 로그인 (★ 본인 구독 OAuth = API 비용 0원)

LOCAL = Claude Pro/Max 본인 OAuth 사용.
처음 실행 시 = 터미널에서 한 번:

```bash
claude /login
```

→ Anthropic 계정 로그인 → 본인 토큰으로 작동.

## .env.local 박기 (자동 셋업이 안 박았으면 직접)

`.env.example` → `.env.local` 복사 후 채움:
```
USE_CLAUDE_CODE=true            # OAuth 모드 (그대로 둠)
ANTHROPIC_API_KEY=              # 비워둠 (OAuth가 처리)
NEXT_PUBLIC_SUPABASE_URL=...    # 사장님께 받음
NEXT_PUBLIC_SUPABASE_ANON_KEY=...  # 사장님께 받음
INVITE_CODE=SUNNY2026!          # 회원가입 베타 코드
```

## 회원가입 / 로그인

- 회원가입 = 초대 코드 `SUNNY2026!` (베타 한정)
- 비번 찾기 = 로그인 페이지 → "비밀번호 찾기" → 이메일 발송 → 링크 → 새 비번 입력

## 사용

```bash
npm run dev      # http://localhost:3001
```

## 새 버전 받기

새 버전 박히면 = 다운로드 페이지 (`/download`)에서 = 새 zip 받아 = 새 폴더에 풀어 = setup 다시.
작품 데이터 = supabase에 저장 = 새 zip 풀어도 = 그대로 유지.

## v2.3 변경사항 (2026-05-04)

- **한 클로드 conversation 모델** — 작품 = 1 conversation. develop·write·chat·adapt·review·osmu·package = 같은 messages 누적. Anthropic prompt cache 1h TTL = 옛 turn cached = 입력 토큰 1/10 + 분당 한도 늦게 도달
- **자료실 풀 페이지** — `/resources` (캐릭터·직업·시대·비유 체계·랜덤 영감·장소)
- **공고 메타 자동 추출** — `/package` 지원사업 모드 = 공고 PDF 업로드 후 = 「📊 메타 추출」 버튼 = 마감일·심사 기준·예산 등 자동 JSON
- **사이드바 라벨 영어** — My Works · Library
- **로그인 시스템** — 회원가입 (`SUNNY2026!`) + 비번 로그인 + 비번 찾기/리셋
