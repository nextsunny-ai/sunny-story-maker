import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import type { User } from "@supabase/supabase-js";

export interface UpdateSessionResult {
  response: NextResponse;
  user: User | null;
}

// 인증 우회 경로 — 로그인·auth 콜백·reset(데이터 초기화)·api·다운로드 페이지 등
const PUBLIC_PATHS = ["/login", "/auth", "/reset", "/api", "/download"];

function isPublicPath(pathname: string): boolean {
  return PUBLIC_PATHS.some(p => pathname === p || pathname.startsWith(p + "/"));
}

export async function updateSession(request: NextRequest): Promise<UpdateSessionResult> {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // CRITICAL: createServerClient와 supabase.auth.getUser() 사이에 어떤 코드도 넣지 말 것.
  // 그렇지 않으면 토큰 갱신 타이밍 문제로 사용자가 임의로 로그아웃될 수 있음.
  const { data } = await supabase.auth.getUser();

  // BYPASS_AUTH=true면 로그인 우회 (사장님 명시 X 시 검증·작가용 LOCAL 본인용)
  const bypassAuth = process.env.BYPASS_AUTH === "true";
  if (bypassAuth) {
    return { response: supabaseResponse, user: data.user };
  }

  // 미인증 + 보호 경로 → /login으로 redirect (원래 가려던 경로는 ?redirect= 로 보존)
  const pathname = request.nextUrl.pathname;
  if (!data.user && !isPublicPath(pathname)) {
    const loginUrl = request.nextUrl.clone();
    loginUrl.pathname = "/login";
    loginUrl.search = `?redirect=${encodeURIComponent(pathname + request.nextUrl.search)}`;
    return { response: NextResponse.redirect(loginUrl), user: null };
  }

  return { response: supabaseResponse, user: data.user };
}
